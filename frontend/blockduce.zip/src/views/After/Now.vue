<template>
  <div>
    <Navbar/>
    <div>
      투표현황
    </div>
  </div>
</template>

<script>
import Navbar from '@/components/Navbar.vue'

export default {
  components: {
    Navbar,
  }


}
</script>

<style>

</style>